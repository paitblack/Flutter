const createOrUpdateNoteRoute = '/notes/new-note/';
